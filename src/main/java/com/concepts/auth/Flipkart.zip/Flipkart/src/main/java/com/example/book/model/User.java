package com.example.book.model;

import java.util.Objects;

public record User(long id, String name, Location location) {
    public User {
        if (name == null || name.isBlank()) throw new IllegalArgumentException("User name is required");
        Objects.requireNonNull(location, "location cannot be null");
    }
}
