package com.example.book.model;

import com.example.book.model.enums.CylinderType;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public class Centre {
    private final long id;
    private final Location location;
    private final Map<CylinderType, Integer> initialStock;

    public Centre(long id, Location location, Map<CylinderType, Integer> stock) {
        if (id <= 0) throw new IllegalArgumentException("centre id must be > 0");
        if (location == null) throw new IllegalArgumentException("location required");

        this.id = id;
        this.location = location;

        Map<CylinderType, Integer> copy = new HashMap<>();
        if (stock != null) {
            for (Map.Entry<CylinderType, Integer> e : stock.entrySet()) {
                if (e.getKey() != null && e.getValue() != null && e.getValue() >= 0) {
                    copy.put(e.getKey(), e.getValue());
                }
            }
        }
        this.initialStock = Collections.unmodifiableMap(copy);
    }

    public long id() { return id; }
    public Location location() { return location; }
    public Map<CylinderType, Integer> initialStock() { return initialStock; }

    public int initialStockOf(CylinderType type) {
        Integer v = initialStock.get(type);
        return v == null ? 0 : v;
    }
}