package com.example.book.service;

import com.example.book.model.Booking;
import com.example.book.model.BookingRequest;
import com.example.book.model.BookingResult;
import com.example.book.model.enums.BookingStatus;
import com.example.book.model.enums.CylinderType;

import java.time.Instant;
import java.util.*;
import java.util.concurrent.locks.ReentrantLock;

public class InventoryQueue {

    private final long centreId;
    private final CylinderType type;
    private final ReentrantLock lock = new ReentrantLock();

    private final Deque<BookingRequest> waitlist = new ArrayDeque<>();
    private final List<Booking> bookings = new ArrayList<>();
    private int available;

    public InventoryQueue(long centreId, CylinderType type, int initialStock) {
        if (centreId <= 0) throw new IllegalArgumentException("bad centre id");
        if (initialStock < 0) throw new IllegalArgumentException("stock can't be negative");
        this.centreId = centreId;
        this.type = Objects.requireNonNull(type);
        this.available = initialStock;
    }

    public Booking tryBook(BookingRequest req) {
        lock.lock();
        try {
            if (!waitlist.isEmpty() || available == 0) {
                return null;
            }
            return doAllocate(req);
        } finally {
            lock.unlock();
        }
    }

    public BookingResult enqueueOrBook(BookingRequest req) {
        lock.lock();
        try {
            if (waitlist.isEmpty() && available > 0) {
                doAllocate(req);
                return new BookingResult(req.id(), BookingStatus.BOOKED, centreId,
                        "booked at centre " + centreId);
            }
            waitlist.addLast(req);
            return new BookingResult(req.id(), BookingStatus.WAITLISTED, centreId,
                    "added to waitlist at " + centreId);
        } finally {
            lock.unlock();
        }
    }

    public List<Booking> receiveStock(int count) {
        if (count <= 0) throw new IllegalArgumentException("count must be > 0");

        lock.lock();
        try {
            available += count;
            List<Booking> newlyBooked = new ArrayList<>();

            while (available > 0 && !waitlist.isEmpty()) {
                BookingRequest next = waitlist.removeFirst();
                newlyBooked.add(doAllocate(next));
            }
            return newlyBooked;
        } finally {
            lock.unlock();
        }
    }

    private Booking doAllocate(BookingRequest req) {
        available--;
        req.markBooked(centreId);
        Booking b = new Booking(UUID.randomUUID(), req.id(), req.user().id(),
                centreId, type, Instant.now());
        bookings.add(b);
        return b;
    }

    public int availableCount() {
        lock.lock();
        try {
            return available;
        } finally {
            lock.unlock();
        }
    }

    public List<BookingRequest> waitlistedRequests() {
        lock.lock();
        try {
            return new ArrayList<>(waitlist);
        } finally {
            lock.unlock();
        }
    }

    public List<Booking> bookings() {
        lock.lock();
        try {
            return new ArrayList<>(bookings);
        } finally {
            lock.unlock();
        }
    }
}