package com.example.book.model.enums;

public enum CylinderType {
    KG_5,
    KG_10,
    KG_13
}
