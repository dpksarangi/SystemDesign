package com.example.book.model;

public class Location {
    private final double x;
    private final double y;

    public Location(double x, double y) {
        if (Double.isNaN(x) || Double.isNaN(y) || Double.isInfinite(x) || Double.isInfinite(y)) {
            throw new IllegalArgumentException("coords must be real numbers");
        }
        this.x = x;
        this.y = y;
    }

    public double x() { return x; }
    public double y() { return y; }

    public double distanceTo(Location other) {
        if (other == null) throw new IllegalArgumentException("other location is null");
        double dx = x - other.x;
        double dy = y - other.y;
        return Math.sqrt(dx * dx + dy * dy);
    }
}