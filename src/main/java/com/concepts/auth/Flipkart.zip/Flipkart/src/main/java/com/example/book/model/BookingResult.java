package com.example.book.model;

import com.example.book.model.enums.BookingStatus;
import java.util.UUID;

public record BookingResult(
        UUID requestId,
        BookingStatus status,
        Long centreId,
        String message) {
}
