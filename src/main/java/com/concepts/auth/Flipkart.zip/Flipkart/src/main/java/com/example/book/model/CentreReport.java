package com.example.book.model;

import com.example.book.model.enums.CylinderType;
import java.util.List;
import java.util.Map;

public record CentreReport(
        long centreId,
        Map<CylinderType, Integer> availableStock,
        List<Booking> bookings,
        List<BookingRequest> waitlistedRequests) {
}
