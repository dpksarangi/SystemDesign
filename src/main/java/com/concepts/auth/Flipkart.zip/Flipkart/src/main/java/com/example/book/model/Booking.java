package com.example.book.model;

import com.example.book.model.enums.CylinderType;
import java.time.Instant;
import java.util.UUID;

public record Booking(
        UUID id,
        UUID requestId,
        long userId,
        long centreId,
        CylinderType cylinderType,
        Instant bookedAt) {
}
