package com.example.book.service;

import com.example.book.model.*;
import com.example.book.model.enums.BookingStatus;
import com.example.book.model.enums.CylinderType;
import org.junit.jupiter.api.Test;

import java.util.*;
import java.util.concurrent.*;

import static org.junit.jupiter.api.Assertions.*;

class LPGBookingServiceTest {

    static final Location ORIGIN = new Location(0, 0);

    @Test
    void booksNearestWithStock() {
        var svc = new LPGBookingService();
        svc.initialize(List.of(
                new Centre(1, new Location(1, 0), Map.of(CylinderType.KG_10, 0)),
                new Centre(2, new Location(2, 0), Map.of(CylinderType.KG_10, 2))
        ));

        var res = svc.bookCylinder(new User(10, "A", new Location(0, 0)), CylinderType.KG_10, 2);

        assertEquals(BookingStatus.BOOKED, res.status());
        assertEquals(2L, res.centreId());
    }

    @Test
    void fallsBackToWaitlistWhenNoStockNearby() {
        LPGBookingService svc = new LPGBookingService();
        svc.initialize(Arrays.asList(
                new Centre(1, new Location(1, 0), Map.of(CylinderType.KG_10, 0)),
                new Centre(2, new Location(2, 0), Map.of(CylinderType.KG_10, 0))
        ));

        BookingResult r = svc.bookCylinder(new User(10, "A", ORIGIN), CylinderType.KG_10, 2);
        assertEquals(BookingStatus.WAITLISTED, r.status());
        assertEquals(1L, r.centreId());
    }

    @Test
    void stockGoesToFirstPersonInQueue() {
        var service = new LPGBookingService();
        service.initialize(List.of(new Centre(1, new Location(1, 0), Map.of(CylinderType.KG_10, 0))));

        User u1 = new User(11, "First", ORIGIN);
        User u2 = new User(12, "Second", ORIGIN);

        service.bookCylinder(u1, CylinderType.KG_10, 1);
        service.bookCylinder(u2, CylinderType.KG_10, 1);

        List<Booking> got = service.receiveStock(1, CylinderType.KG_10, 1);

        assertEquals(1, got.size());
        assertEquals(u1.id(), got.get(0).userId());

        // second guy should still be waiting
        assertEquals(1, service.generateReport(1).waitlistedRequests().size());
        assertEquals(u2.id(), service.generateReport(1).waitlistedRequests().get(0).user().id());
    }

    @Test
    void cantBookBeforeInit() {
        assertThrows(IllegalStateException.class, () ->
                new LPGBookingService().bookCylinder(new User(1, "A", ORIGIN), CylinderType.KG_10, 1));
    }

    @Test
    void rejectsDuplicateCentreIds() {
        LPGBookingService s = new LPGBookingService();
        Centre c1 = new Centre(1, new Location(1, 1), Map.of());
        Centre c2 = new Centre(1, new Location(2, 2), Map.of());

        assertThrows(IllegalArgumentException.class, () -> s.initialize(List.of(c1, c2)));
    }

    @Test
    void unknownCentreOnReceiveStock() {
        var svc = new LPGBookingService();
        svc.initialize(List.of(new Centre(1, new Location(1, 1), Map.of())));

        assertThrows(IllegalArgumentException.class,
                () -> svc.receiveStock(99, CylinderType.KG_10, 1));
    }

    @Test
    void zeroStockCountRejected() {
        LPGBookingService svc = new LPGBookingService();
        svc.initialize(List.of(new Centre(1, new Location(1, 1), Map.of())));
        assertThrows(IllegalArgumentException.class, () -> svc.receiveStock(1, CylinderType.KG_10, 0));
    }

    @Test
    void differentCylinderTypesDontInterfere() {
        LPGBookingService svc = new LPGBookingService();
        svc.initialize(List.of(new Centre(1, new Location(1, 1),
                Map.of(CylinderType.KG_5, 1, CylinderType.KG_10, 0))));

        User u = new User(1, "A", ORIGIN);
        var r10 = svc.bookCylinder(u, CylinderType.KG_10, 1);
        var r5  = svc.bookCylinder(u, CylinderType.KG_5, 1);

        assertEquals(BookingStatus.WAITLISTED, r10.status());
        assertEquals(BookingStatus.BOOKED, r5.status());
        assertEquals(0, (int) svc.generateReport(1).availableStock().get(CylinderType.KG_5));
    }

    @Test
    void waitlistOnlyOnNearest() {
        var svc = new LPGBookingService();
        svc.initialize(List.of(
                new Centre(1, new Location(1, 0), Map.of()),
                new Centre(2, new Location(5, 0), Map.of())
        ));

        svc.bookCylinder(new User(1, "A", ORIGIN), CylinderType.KG_10, 2);

        assertEquals(1, svc.generateReport(1).waitlistedRequests().size());
        assertTrue(svc.generateReport(2).waitlistedRequests().isEmpty());
    }

    @Test
    void stockAtFarCentreDoesNothingForWaitlist() {
        LPGBookingService svc = new LPGBookingService();
        svc.initialize(List.of(
                new Centre(1, new Location(1, 0), Map.of()),
                new Centre(2, new Location(5, 0), Map.of())
        ));
        svc.bookCylinder(new User(1, "A", ORIGIN), CylinderType.KG_10, 2);

        List<Booking> fulfilled = svc.receiveStock(2, CylinderType.KG_10, 1);
        assertTrue(fulfilled.isEmpty());
        assertEquals(1, (int) svc.generateReport(2).availableStock().get(CylinderType.KG_10));
    }

    @Test
    void leftoverStockStays() {
        var svc = new LPGBookingService();
        svc.initialize(List.of(new Centre(1, new Location(1, 0), Map.of())));
        svc.bookCylinder(new User(1, "A", ORIGIN), CylinderType.KG_10, 1);
        svc.bookCylinder(new User(2, "B", ORIGIN), CylinderType.KG_10, 1);

        List<Booking> got = svc.receiveStock(1, CylinderType.KG_10, 3);
        assertEquals(2, got.size());

        CentreReport rep = svc.generateReport(1);
        assertEquals(1, (int) rep.availableStock().get(CylinderType.KG_10));
        assertTrue(rep.waitlistedRequests().isEmpty());
    }

    //rough concurrency check
    @Test
    void concurrentBookingDoesntOversell() throws Exception {
        int stock = 10;
        int n = 40;
        LPGBookingService svc = new LPGBookingService();
        svc.initialize(List.of(new Centre(1, new Location(1, 1), Map.of(CylinderType.KG_10, stock))));

        ExecutorService pool = Executors.newFixedThreadPool(6);
        CountDownLatch gate = new CountDownLatch(1);
        List<Future<BookingResult>> futures = new ArrayList<>();

        for (int i = 0; i < n; i++) {
            final long id = i + 1;
            futures.add(pool.submit(() -> {
                gate.await();
                return svc.bookCylinder(new User(id, "u" + id, ORIGIN), CylinderType.KG_10, 1);
            }));
        }
        gate.countDown();

        int booked = 0;
        for (Future<BookingResult> f : futures) {
            if (f.get(3, TimeUnit.SECONDS).status() == BookingStatus.BOOKED) {
                booked++;
            }
        }
        pool.shutdown();

        assertEquals(stock, booked);

        CentreReport r = svc.generateReport(1);
        assertEquals(stock, r.bookings().size());
        assertEquals(n - stock, r.waitlistedRequests().size());
        assertEquals(0, (int) r.availableStock().get(CylinderType.KG_10));
    }
}