package com.example.book.service;

import com.example.book.model.Centre;
import com.example.book.model.enums.CylinderType;
import java.util.Collections;
import java.util.EnumMap;
import java.util.Map;

public final class CentreInventory {
    private final long centreId;
    private final Map<CylinderType, InventoryQueue> byType = new EnumMap<>(CylinderType.class);

    public CentreInventory(Centre centre) {
        this.centreId = centre.id();
        for (CylinderType type : CylinderType.values()) {
            byType.put(type, new InventoryQueue(centreId, type, centre.initialStockOf(type)));
        }
    }

    public long centreId() {
        return centreId;
    }

    public InventoryQueue forType(CylinderType type) {
        InventoryQueue queue = byType.get(type);
        if (queue == null) throw new IllegalArgumentException("Unsupported cylinder type: " + type);
        return queue;
    }

    public Map<CylinderType, Integer> availableStock() {
        EnumMap<CylinderType, Integer> result = new EnumMap<>(CylinderType.class);
        byType.forEach((type, queue) -> result.put(type, queue.availableCount()));
        return Collections.unmodifiableMap(result);
    }

    public Map<CylinderType, InventoryQueue> queues() {
        return Collections.unmodifiableMap(byType);
    }
}
