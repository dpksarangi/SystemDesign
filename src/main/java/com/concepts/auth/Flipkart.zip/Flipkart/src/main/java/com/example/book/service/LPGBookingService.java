package com.example.book.service;

import com.example.book.model.*;
import com.example.book.model.enums.BookingStatus;
import com.example.book.model.enums.CylinderType;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class LPGBookingService {

    private final CentreLocator locator;
    private final Map<Long, Centre> centres = new ConcurrentHashMap<>();
    private final Map<Long, CentreInventory> inventories = new ConcurrentHashMap<>();

    public LPGBookingService() {
        this(new CentreLocator());
    }

    public LPGBookingService(CentreLocator locator) {
        this.locator = Objects.requireNonNull(locator);
    }

    public void initialize(List<Centre> centreList) {
        if (centreList == null) throw new IllegalArgumentException("centres required");

        Map<Long, Centre> tmpCentres = new HashMap<>();
        Map<Long, CentreInventory> tmpInv = new HashMap<>();

        for (Centre c : centreList) {
            if (c == null) continue;
            if (tmpCentres.containsKey(c.id())) {
                throw new IllegalArgumentException("duplicate centre: " + c.id());
            }
            tmpCentres.put(c.id(), c);
            tmpInv.put(c.id(), new CentreInventory(c));
        }

        centres.clear();
        centres.putAll(tmpCentres);
        inventories.clear();
        inventories.putAll(tmpInv);
    }

    public BookingResult bookCylinder(User user, CylinderType type, int nearestCount) {
        if (user == null || type == null) throw new IllegalArgumentException("user/type required");
        if (nearestCount <= 0) throw new IllegalArgumentException("nearestCount must be positive");
        if (centres.isEmpty()) throw new IllegalStateException("not initialized");

        BookingRequest request = new BookingRequest(user, type);
        List<Centre> nearest = locator.findNearest(user.location(), new ArrayList<>(centres.values()), nearestCount);

        for (Centre c : nearest) {
            InventoryQueue q = inventories.get(c.id()).forType(type);
            Booking b = q.tryBook(request);
            if (b != null) {
                return new BookingResult(request.id(), BookingStatus.BOOKED, c.id(), "Cylinder booked at centre " + c.id());
            }
        }

        Centre preferred = nearest.get(0);
        return inventories.get(preferred.id()).forType(type).enqueueOrBook(request);
    }

    public List<Booking> receiveStock(long centreId, CylinderType type, int count) {
        return getInventory(centreId).forType(type).receiveStock(count);
    }

    public CentreReport generateReport(long centreId) {
        CentreInventory inv = getInventory(centreId);

        List<Booking> allBookings = new ArrayList<>();
        List<BookingRequest> waiting = new ArrayList<>();

        for (InventoryQueue q : inv.queues().values()) {
            allBookings.addAll(q.bookings());
            waiting.addAll(q.waitlistedRequests());
        }

        // oldest first
        allBookings.sort(Comparator.comparing(Booking::bookedAt));

        return new CentreReport(centreId, inv.availableStock(), allBookings, waiting);
    }

    private CentreInventory getInventory(long centreId) {
        CentreInventory inv = inventories.get(centreId);
        if (inv == null) throw new IllegalArgumentException("unknown centre " + centreId);
        return inv;
    }
}