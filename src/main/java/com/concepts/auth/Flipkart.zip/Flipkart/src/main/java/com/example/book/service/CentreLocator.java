package com.example.book.service;

import com.example.book.model.Centre;
import com.example.book.model.Location;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class CentreLocator {

    public List<Centre> findNearest(Location userLoc, List<Centre> centres, int n) {
        if (userLoc == null || centres == null) {
            throw new IllegalArgumentException("location and centres required");
        }
        if (n <= 0) {
            throw new IllegalArgumentException("n must be > 0");
        }

        List<Centre> copy = new ArrayList<>();
        for (Centre c : centres) {
            if (c != null) {
                copy.add(c);
            }
        }

        Collections.sort(copy, new Comparator<Centre>() {
            public int compare(Centre a, Centre b) {
                double d1 = userLoc.distanceTo(a.location());
                double d2 = userLoc.distanceTo(b.location());
                return Double.compare(d1, d2);
            }
        });

        if (n >= copy.size()) {
            return copy;
        }
        return copy.subList(0, n);
    }
}