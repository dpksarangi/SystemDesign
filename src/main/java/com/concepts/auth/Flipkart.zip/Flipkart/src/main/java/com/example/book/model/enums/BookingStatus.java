package com.example.book.model.enums;

public enum BookingStatus {
    WAITLISTED,
    BOOKED
}
