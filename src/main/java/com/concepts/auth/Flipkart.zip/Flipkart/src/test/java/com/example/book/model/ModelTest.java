package com.example.book.model;

import com.example.book.model.enums.BookingStatus;
import com.example.book.model.enums.CylinderType;
import org.junit.jupiter.api.Test;

import java.util.EnumMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

class ModelTest {

    private static final Location ORIGIN = new Location(0, 0);

    @Test
    void userRejectsBlankName() {
        assertThrows(IllegalArgumentException.class, () -> new User(1, "   ", ORIGIN));
    }


    @Test
    void centreCopiesTheStockMapItIsGiven() {
        Map<CylinderType, Integer> stock = new EnumMap<>(CylinderType.class);
        stock.put(CylinderType.KG_5, 3);
        Centre centre = new Centre(1, ORIGIN, stock);

        stock.put(CylinderType.KG_5, 99);

        assertEquals(3, centre.initialStockOf(CylinderType.KG_5));
    }

    @Test
    void centreReportsZeroForTypesItWasNotGiven() {
        Centre centre = new Centre(1, ORIGIN, Map.of(CylinderType.KG_5, 3));

        assertEquals(0, centre.initialStockOf(CylinderType.KG_13));
    }


    @Test
    void newBookingRequestStartsWaitlisted() {
        BookingRequest request = new BookingRequest(new User(1, "A", ORIGIN), CylinderType.KG_10);

        assertEquals(BookingStatus.WAITLISTED, request.status());
    }

    @Test
    void markBookedUpdatesStatusAndCentre() {
        BookingRequest request = new BookingRequest(new User(1, "A", ORIGIN), CylinderType.KG_10);

        request.markBooked(7);

        assertEquals(BookingStatus.BOOKED, request.status());
        assertEquals(7L, request.assignedCentreId());
    }
}
