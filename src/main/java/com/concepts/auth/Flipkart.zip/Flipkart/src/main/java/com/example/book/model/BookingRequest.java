package com.example.book.model;

import com.example.book.model.enums.BookingStatus;
import com.example.book.model.enums.CylinderType;
import java.time.Instant;
import java.util.Objects;
import java.util.UUID;

public final class BookingRequest {
    private final UUID id;
    private final User user;
    private final CylinderType cylinderType;
    private final Instant createdAt;
    private volatile BookingStatus status;
    private volatile Long assignedCentreId;

    public BookingRequest(User user, CylinderType cylinderType) {
        this.id = UUID.randomUUID();
        this.user = Objects.requireNonNull(user, "user cannot be null");
        this.cylinderType = Objects.requireNonNull(cylinderType, "cylinderType cannot be null");
        this.createdAt = Instant.now();
        this.status = BookingStatus.WAITLISTED;
    }

    public UUID id() { return id; }
    public User user() { return user; }
    public CylinderType cylinderType() { return cylinderType; }

    public Instant createdAt() { return createdAt; }
    public BookingStatus status() { return status; }
    public Long assignedCentreId() { return assignedCentreId; }

    public void markBooked(long centreId) {
        this.assignedCentreId = centreId;
        this.status = BookingStatus.BOOKED;
    }
}
