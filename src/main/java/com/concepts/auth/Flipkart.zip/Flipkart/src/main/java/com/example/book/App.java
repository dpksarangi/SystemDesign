package com.example.book;

import com.example.book.model.*;
import com.example.book.model.enums.CylinderType;
import com.example.book.service.CentreLocator;
import com.example.book.service.LPGBookingService;
import java.util.List;
import java.util.Map;

public class App {

    public static void main(String[] args) {
        Location userLocation = new Location(10, 20);

        List<Centre> centres = List.of(
                new Centre(101, new Location(11, 21), Map.of(CylinderType.KG_10, 1)),
                new Centre(102, new Location(13, 24), Map.of(CylinderType.KG_10, 0)),
                new Centre(103, new Location(15, 22), Map.of(CylinderType.KG_10, 0))
        );

        CentreLocator locator = new CentreLocator();
        List<Centre> nearest = locator.findNearest(userLocation, centres, 3);

        System.out.println("=== Nearest centres ===");
        for (Centre centre : nearest) {
            double distance = userLocation.distanceTo(centre.location());

            System.out.printf(
                    "Centre %d | distance %.2f%n",
                    centre.id(),
                    distance
            );
        }

        LPGBookingService bookingService = new LPGBookingService(locator);
        bookingService.initialize(centres);

        User user1 = new User(1, "Asha", userLocation);
        User user2 = new User(2, "Ravi", userLocation);

        System.out.println("\n=== Booking requests ===");
        BookingResult first = bookingService.bookCylinder(user1, CylinderType.KG_10, 3);
        System.out.println("Asha: " + first);

        BookingResult second = bookingService.bookCylinder(user2, CylinderType.KG_10, 3);
        System.out.println("Ravi: " + second);

        System.out.println("\n=== Stock receipt ===");
        List<Booking> fulfilled = bookingService.receiveStock(101, CylinderType.KG_10, 1);
        System.out.println("Newly fulfilled bookings: " + fulfilled);

        System.out.println("\n=== Centre 101 report ===");
        CentreReport report = bookingService.generateReport(101);
        System.out.println("Available stock: " + report.availableStock());
        System.out.println("Bookings: " + report.bookings());
        System.out.println("Pending waitlist: " + report.waitlistedRequests());
    }
}
