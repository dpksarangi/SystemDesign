package com.example.book.model;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class LocationTest {

    @Test
    void calculatesEuclideanDistance() {
        Location a = new Location(10, 20);
        Location b = new Location(13, 24);

        assertEquals(5.0, a.distanceTo(b), 0.000001);
    }

    @Test
    void rejectsNonFiniteCoordinates() {
        assertThrows(IllegalArgumentException.class,
                () -> new Location(Double.NaN, 2));
    }
}
