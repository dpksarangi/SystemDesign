package com.example.book.service;

import com.example.book.model.Centre;
import com.example.book.model.Location;
import org.junit.jupiter.api.Test;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

class CentreLocatorTest {

    private final CentreLocator locator = new CentreLocator();

    @Test
    void returnsNearestCentresInAscendingDistanceOrder() {
        Location user = new Location(5, 5);
        List<Centre> centres = List.of(
                new Centre(1, new Location(8, 9), Map.of()),
                new Centre(2, new Location(6, 6), Map.of()),
                new Centre(3, new Location(10, 5), Map.of())
        );

        List<Centre> result = locator.findNearest(user, centres, 2);

        assertEquals(List.of(2L, 1L), result.stream().map(Centre::id).toList());
    }

    @Test
    void returnsAllCentresWhenNIsLargerThanCentreCount() {
        List<Centre> centres = List.of(
                new Centre(1, new Location(1, 1), Map.of()),
                new Centre(2, new Location(2, 2), Map.of())
        );

        assertEquals(2, locator.findNearest(new Location(0, 0), centres, 10).size());
    }

    @Test
    void rejectsZeroNearestCount() {
        assertThrows(IllegalArgumentException.class,
                () -> locator.findNearest(new Location(0, 0), List.of(), 0));
    }
}
